const express = require("express");
const router = express.Router();

const decorations = [
  {id:1,name:"Classic Flower Decor",category:"Classic",price:8000},
  {id:2,name:"Royal Stage Decor",category:"Royal",price:15000},
  {id:3,name:"Premium LED Decor",category:"Premium",price:18000},
  {id:4,name:"Traditional Decor",category:"Traditional",price:10000},
  {id:5,name:"Birthday Theme",category:"Birthday",price:7000},
  {id:6,name:"Wedding Theme",category:"Wedding",price:20000},
  {id:7,name:"Reception Theme",category:"Reception",price:16000}
];

router.get("/", (req,res) => res.json(decorations));
module.exports = router;
