const express = require("express");
const router = express.Router();

const menu = [
  {id:1,name:"South Indian Veg Meals",type:"veg",category:"Meals",price:220},
  {id:2,name:"North Indian Veg Buffet",type:"veg",category:"Buffet",price:280},
  {id:3,name:"Veg Biryani",type:"veg",category:"Rice",price:100},
  {id:4,name:"Paneer Butter Masala",type:"veg",category:"Curry",price:90},
  {id:5,name:"Gobi Manchurian",type:"veg",category:"Starter",price:80},
  {id:6,name:"Masala Dosa Counter",type:"veg",category:"Live Counter",price:90},
  {id:7,name:"Chicken Biryani",type:"nonveg",category:"Rice",price:180},
  {id:8,name:"Mutton Biryani",type:"nonveg",category:"Rice",price:260},
  {id:9,name:"Chicken 65",type:"nonveg",category:"Starter",price:120},
  {id:10,name:"Chicken Curry",type:"nonveg",category:"Curry",price:130},
  {id:11,name:"Fish Fry",type:"nonveg",category:"Starter",price:160},
  {id:12,name:"Mutton Curry",type:"nonveg",category:"Curry",price:190}
];

router.get("/", (req,res) => res.json(menu));
module.exports = router;
