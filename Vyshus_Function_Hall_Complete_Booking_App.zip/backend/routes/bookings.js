const express = require("express");
const fs = require("fs");
const path = require("path");
const router = express.Router();

const file = path.join(__dirname, "..", "data", "bookings.json");

function readBookings() {
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, "utf8") || "[]");
}

function writeBookings(bookings) {
  fs.writeFileSync(file, JSON.stringify(bookings, null, 2));
}

router.get("/", (req,res) => {
  res.json(readBookings());
});

router.post("/", (req,res) => {
  const data = req.body;

  if (!data.customerName || !data.phone || !data.eventDate ||
      !data.guests || !data.food || !data.decoration) {
    return res.status(400).json({
      success:false,
      message:"Please complete all required booking details."
    });
  }

  const bookings = readBookings();

  const booking = {
    bookingId: "VYSHU-" + Date.now(),
    customerName: data.customerName,
    phone: data.phone,
    email: data.email || "",
    eventType: data.eventType || "Function",
    eventDate: data.eventDate,
    guests: Number(data.guests),
    food: data.food,
    facilities: data.facilities || [],
    decoration: data.decoration,
    totals: data.totals || {},
    status: "Confirmed",
    createdAt: new Date().toISOString()
  };

  bookings.push(booking);
  writeBookings(bookings);

  res.status(201).json({
    success:true,
    message:"Booking confirmed successfully!",
    booking
  });
});

router.delete("/:bookingId", (req,res) => {
  const bookings = readBookings();
  const index = bookings.findIndex(b => b.bookingId === req.params.bookingId);

  if (index === -1) {
    return res.status(404).json({
      success:false,
      message:"Booking not found."
    });
  }

  bookings[index].status = "Cancelled";
  bookings[index].cancelledAt = new Date().toISOString();
  writeBookings(bookings);

  res.json({
    success:true,
    message:"Booking cancelled successfully.",
    booking:bookings[index]
  });
});

module.exports = router;
