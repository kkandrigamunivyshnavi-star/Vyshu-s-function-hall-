const express = require("express");
const router = express.Router();

const facilities = [
  {id:1,name:"Premium Chairs",category:"Seating",price:1500},
  {id:2,name:"Banquet Chairs",category:"Seating",price:2500},
  {id:3,name:"Round Dining Tables",category:"Tables",price:2000},
  {id:4,name:"Dining Tables",category:"Tables",price:2500},
  {id:5,name:"Grand Stage Setup",category:"Stage",price:5000},
  {id:6,name:"Professional Sound System",category:"Audio",price:3500},
  {id:7,name:"LED Screen",category:"Display",price:6000},
  {id:8,name:"Generator Backup",category:"Power",price:4500},
  {id:9,name:"Air Conditioning",category:"Comfort",price:7000}
];

router.get("/", (req,res) => res.json(facilities));
module.exports = router;
