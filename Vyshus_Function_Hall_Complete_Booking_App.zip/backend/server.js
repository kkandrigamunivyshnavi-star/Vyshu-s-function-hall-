const express = require("express");
const cors = require("cors");
const path = require("path");

const menuRoutes = require("./routes/menu");
const facilityRoutes = require("./routes/facilities");
const decorationRoutes = require("./routes/decorations");
const bookingRoutes = require("./routes/bookings");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.use("/api/menu", menuRoutes);
app.use("/api/facilities", facilityRoutes);
app.use("/api/decorations", decorationRoutes);
app.use("/api/bookings", bookingRoutes);

app.use(express.static(path.join(__dirname, "..", "frontend")));

app.get("/api/health", (req, res) => {
  res.json({ success: true, message: "Vyshu's Function Hall backend is running." });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "frontend", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Vyshu's Function Hall: http://localhost:${PORT}`);
});
