let menu=[],facilities=[],decorations=[];
let selectedFood=null,selectedFacilities=[],selectedDecoration=null;

const money=n=>"₹"+Number(n||0).toLocaleString("en-IN");

async function load(){
  [menu,facilities,decorations]=await Promise.all([
    fetch("/api/menu").then(r=>r.json()),
    fetch("/api/facilities").then(r=>r.json()),
    fetch("/api/decorations").then(r=>r.json())
  ]);
  renderMenu("veg"); renderFacilities(); renderDecor(); renderChoices(); calc(); loadBookings();
}

function renderMenu(type){
  document.getElementById("menuGrid").innerHTML=menu.filter(x=>x.type===type).map(x=>`
    <article class="food">
      <div class="icon">${type==="veg"?"🥗":"🍗"}</div>
      <span class="cat">${x.category}</span>
      <h3>${x.name}</h3>
      <div class="price">${money(x.price)} / guest
        <button class="choose ${selectedFood?.id===x.id?"selected":""}" onclick="chooseFood(${x.id})">
          ${selectedFood?.id===x.id?"Selected":"Choose"}
        </button>
      </div>
    </article>`).join("");
}

function chooseFood(id){
  selectedFood=menu.find(x=>x.id===id);
  renderMenu(selectedFood.type); renderChoices(); calc();
  document.getElementById("booking").scrollIntoView({behavior:"smooth"});
}

function renderFacilities(){
  document.getElementById("facilityGrid").innerHTML=facilities.map(x=>`
    <label class="option">
      <span><b>${x.name}</b><small>${x.category}</small></span>
      <span><input type="checkbox" onchange="toggleFacility(${x.id},this.checked)"> ${money(x.price)}</span>
    </label>`).join("");
}

function toggleFacility(id,on){
  const item=facilities.find(x=>x.id===id);
  if(on) selectedFacilities.push(item);
  else selectedFacilities=selectedFacilities.filter(x=>x.id!==id);
  renderChoices(); calc();
}

function renderDecor(){
  document.getElementById("decorationGrid").innerHTML=decorations.map(x=>`
    <div class="dec ${selectedDecoration?.id===x.id?"selected":""}" onclick="chooseDecor(${x.id})">
      <p>${x.category}</p><h4>${x.name}</h4><b>${money(x.price)}</b>
    </div>`).join("");
}

function chooseDecor(id){
  selectedDecoration=decorations.find(x=>x.id===id);
  renderDecor(); renderChoices(); calc();
}

function renderChoices(){
  document.getElementById("foodChoices").innerHTML=selectedFood
    ? `<div class="choice active"><span>🍽️ ${selectedFood.name}</span><b>${money(selectedFood.price)} / guest</b></div>`
    : `<div class="choice">Choose a food package above.</div>`;

  document.getElementById("setupChoices").innerHTML=selectedFacilities.length
    ? selectedFacilities.map(x=>`<div class="choice active"><span>✓ ${x.name}</span><b>${money(x.price)}</b></div>`).join("")
    : `<div class="choice">No additional facilities selected.</div>`;

  document.getElementById("decorChoices").innerHTML=selectedDecoration
    ? `<div class="choice active"><span>🌸 ${selectedDecoration.name}</span><b>${money(selectedDecoration.price)}</b></div>`
    : `<div class="choice">Choose a decoration theme above.</div>`;
}

function calc(){
  const guests=Number(document.querySelector('[name=guests]').value||0);
  const foodTotal=(selectedFood?.price||0)*guests;
  const facilityTotal=selectedFacilities.reduce((s,x)=>s+x.price,0);
  const decorationTotal=selectedDecoration?.price||0;
  const grandTotal=foodTotal+facilityTotal+decorationTotal;

  document.getElementById("foodTotal").textContent=money(foodTotal);
  document.getElementById("facilityTotal").textContent=money(facilityTotal);
  document.getElementById("decorationTotal").textContent=money(decorationTotal);
  document.getElementById("grandTotal").textContent=money(grandTotal);
  return {foodTotal,facilityTotal,decorationTotal,grandTotal};
}

document.querySelector('[name=guests]').addEventListener("input",calc);

document.querySelectorAll(".tab").forEach(btn=>{
  btn.onclick=()=>{
    document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));
    btn.classList.add("active");
    renderMenu(btn.dataset.type);
  };
});

document.getElementById("bookingForm").onsubmit=async e=>{
  e.preventDefault();

  if(!selectedFood || !selectedDecoration){
    toast("Please choose food and decoration.");
    return;
  }

  const f=new FormData(e.target);
  const payload={
    customerName:f.get("customerName"),
    phone:f.get("phone"),
    email:f.get("email"),
    eventType:f.get("eventType"),
    eventDate:f.get("eventDate"),
    guests:Number(f.get("guests")),
    food:selectedFood,
    facilities:selectedFacilities,
    decoration:selectedDecoration,
    totals:calc()
  };

  try{
    const r=await fetch("/api/bookings",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(payload)
    });
    const j=await r.json();

    if(j.success){
      toast("Booking confirmed! ID: "+j.booking.bookingId);
      e.target.reset();
      document.querySelector('[name=guests]').value=100;
      document.querySelectorAll('input[type=checkbox]').forEach(x=>x.checked=false);
      selectedFood=null; selectedFacilities=[]; selectedDecoration=null;
      renderMenu("veg"); renderDecor(); renderChoices(); calc(); loadBookings();
    }else toast(j.message||"Booking failed.");
  }catch(err){toast("Cannot connect to backend.");}
};

async function loadBookings(){
  try{
    const bookings=await fetch("/api/bookings").then(r=>r.json());
    const box=document.getElementById("bookingList");

    if(!bookings.length){
      box.innerHTML='<div class="empty">No bookings yet. Your confirmed bookings will appear here.</div>';
      return;
    }

    box.innerHTML=bookings.slice().reverse().map(b=>`
      <div class="booking-card">
        <div>
          <h3>${escapeHtml(b.customerName)}</h3>
          <p><span class="booking-id">${b.bookingId}</span> · ${escapeHtml(b.eventType)} · ${escapeHtml(b.eventDate)}</p>
          <p>👥 ${b.guests} guests · 🍽️ ${escapeHtml(b.food.name)} · 🌸 ${escapeHtml(b.decoration.name)}</p>
          <p>Facilities: ${b.facilities.length ? b.facilities.map(x=>escapeHtml(x.name)).join(", ") : "None"}</p>
          <p><strong>Total: ${money(b.totals?.grandTotal)}</strong></p>
        </div>
        <div>
          <span class="status ${b.status==="Cancelled"?"cancelled":"confirmed"}">${b.status}</span><br><br>
          <button class="cancel" ${b.status==="Cancelled"?"disabled":""} onclick="cancelBooking('${b.bookingId}')">
            ${b.status==="Cancelled"?"Cancelled":"Cancel Booking"}
          </button>
        </div>
      </div>`).join("");
  }catch(e){
    document.getElementById("bookingList").innerHTML='<div class="empty">Unable to load booking list.</div>';
  }
}

async function cancelBooking(id){
  if(!confirm("Are you sure you want to cancel this booking?")) return;

  try{
    const r=await fetch("/api/bookings/"+encodeURIComponent(id),{method:"DELETE"});
    const j=await r.json();
    toast(j.message||"Booking cancelled.");
    loadBookings();
  }catch(e){toast("Could not cancel booking.");}
}

function escapeHtml(value){
  return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

function toast(msg){
  const t=document.getElementById("toast");
  t.textContent=msg; t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),4500);
}

load().catch(()=>toast("Cannot connect to Node.js backend."));
