# Vyshu's Function Hall - Complete Online Booking

Full-stack Node.js web application for Vyshu's Function Hall.

## Included
- Beautiful responsive frontend
- Veg and Non-Veg food selection
- Multiple food varieties
- Decoration themes
- Chairs, tables, stage, sound, LED, generator and AC facilities
- Automatic price calculation
- Online booking
- Booking ID generation
- Booking list
- Booking cancellation
- Node.js + Express backend
- REST APIs
- JSON data storage

## Run
Install Node.js 18+.

Open terminal in the `backend` folder:

```bash
npm install
npm start
```

Open:

http://localhost:5000

## Main APIs
GET  /api/menu
GET  /api/facilities
GET  /api/decorations
GET  /api/bookings
POST /api/bookings
DELETE /api/bookings/:bookingId

The JSON storage can later be replaced with MySQL/MongoDB.
